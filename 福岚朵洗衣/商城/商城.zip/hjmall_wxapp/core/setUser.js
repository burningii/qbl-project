module.exports = function(t) {
    this.core.setStorageSync(this.const.USER_INFO, t);
};