module.exports = {
    name: "精选科技",
    uniacid: "17",
    acid: "17",
    multiid: "0",
    version: "1.21",
  siteroot: "https://qblwx3.qibuluo.net/app/index.php",
    design_method: "3"
};
